// js/auth.js — Đăng nhập/đăng ký/đăng xuất, cache tiến độ cục bộ (progressCache_*), đồng bộ progress.ui lên server (scheduleSync)
// ════════════════════════════════════════════════════
// TÀI KHOẢN / ĐỒNG BỘ TIẾN ĐỘ VỚI SERVER
// ════════════════════════════════════════════════════
let authToken = localStorage.getItem('authToken') || null;
let authUsername = localStorage.getItem('authUsername') || null;
// Đã bỏ chức năng dùng thử (khách) — dọn dữ liệu chế độ khách cũ còn sót trong trình duyệt.
try { localStorage.removeItem('authGuest'); localStorage.removeItem('guestProgress'); } catch {}
// "ui" lưu lại trạng thái đang thao tác dở (tab đang xem, Quyển/level + bài đang chọn) —
// được đồng bộ lên server cùng tiến độ học, để mở lại app (kể cả trên máy khác) vẫn đúng chỗ cũ.
// V136 — tỷ lệ xuất hiện từng DẠNG BÀI trong "Hôm nay học" (Cài đặt hằng ngày). 0 = Tắt, 0.5 = Ít,
// 1 = Vừa, 2 = Nhiều. Chỉ là hệ số nhân vào điểm của bộ chọn (js/question-selector.js). "Điền từ vào câu"
// mặc định Nhiều: người học phản ánh dạng này ra quá ít so với nhu cầu luyện dùng từ trong ngữ cảnh.
const QUESTION_MIX_TYPES = ['hz2vi', 'vi2hz', 'listen2hz', 'listen2vi', 'hz2py', 'cloze'];
const QUESTION_MIX_DEFAULT = { cloze: 2 };
function normalizeQuestionMix(m) {
  const src = (m && typeof m === 'object') ? m : {};
  const out = {};
  for (const k of QUESTION_MIX_TYPES) {
    const v = Number(src[k]);
    out[k] = Number.isFinite(v) ? Math.max(0, Math.min(2, v)) : (QUESTION_MIX_DEFAULT[k] == null ? 1 : QUESTION_MIX_DEFAULT[k]);
  }
  return out;
}
function defaultProgress() {
  return { srs: {}, streak: 0, lastDate: null, ui: {
    lastTab: 'home', selectedBookIds: [1], selectedLessons: [], lessonsAllMode: true,
    showPinyin: true, showMeaning: true, showHanViet: true, theme: 'light', ttsRate: 0.9, ttsVoice: 'zh-CN-XiaoxiaoNeural',
    qzType: '漢→Việt', qzQuestionCount: 30, questionCount: 10,
    // Cài đặt hệ thống học FSRS (Phần 22): daily limit + current lesson tự động cập nhật.
    dailyReviewLimit: 50, dailyNewLimit: 10, newOnlyAfterDue: true, currentLesson: null,
    // unlimitedStudy: bật thì bỏ qua phần TRỪ theo số đã học hôm nay (không bị chặn "hết hạn mức,
    // quay lại ngày mai") — KHÔNG bỏ 2 giới hạn trên, mỗi lượt lấy phiên vẫn đúng số đã đặt (V101).
    unlimitedStudy: false,
    // V135: số câu "🧩 Sắp xếp câu" (luyện bổ sung, KHÔNG đổi lịch FSRS) chèn vào mỗi buổi "Hôm nay học". 0–5.
    orderSentencePerSession: 2,
    // V136: tỷ lệ từng dạng bài (xem QUESTION_MIX_TYPES).
    questionMix: normalizeQuestionMix(),
  } };
}
function normalizeProgress(p) {
  if (!p || typeof p !== 'object') return defaultProgress();
  if (!p.srs) p.srs = {};
  if (typeof p.streak !== 'number') p.streak = 0;
  if (p.lastDate === undefined) p.lastDate = null;
  if (!p.ui || typeof p.ui !== 'object') p.ui = defaultProgress().ui;
  if (!p.ui.lastTab) p.ui.lastTab = 'home';
  if (!Array.isArray(p.ui.selectedBookIds)) p.ui.selectedBookIds = [1];
  if (!Array.isArray(p.ui.selectedLessons)) p.ui.selectedLessons = [];
  if (typeof p.ui.lessonsAllMode !== 'boolean') p.ui.lessonsAllMode = (p.ui.selectedLessons.length === 0);
  if (typeof p.ui.showPinyin !== 'boolean') p.ui.showPinyin = true;
  if (typeof p.ui.showMeaning !== 'boolean') p.ui.showMeaning = true;
  if (typeof p.ui.showHanViet !== 'boolean') p.ui.showHanViet = true;
  if (p.ui.theme !== 'dark' && p.ui.theme !== 'light') p.ui.theme = 'light';
  // V139 Edge-TTS: tốc độ hợp lệ 0.8–1.2x; giá trị cũ 0.3–1.0 được đưa về mặc định an toàn.
  if (typeof p.ui.ttsRate !== 'number' || p.ui.ttsRate < 0.8 || p.ui.ttsRate > 1.2) p.ui.ttsRate = 0.9;
  if (!['zh-CN-XiaoxiaoNeural', 'zh-CN-YunxiNeural'].includes(p.ui.ttsVoice)) p.ui.ttsVoice = 'zh-CN-XiaoxiaoNeural';
  if (!['漢→Việt', 'Việt→漢', 'Âm→漢'].includes(p.ui.qzType)) p.ui.qzType = '漢→Việt';
  if (!Number.isFinite(p.ui.qzQuestionCount)) p.ui.qzQuestionCount = 30;
  if (!Number.isFinite(p.ui.questionCount)) p.ui.questionCount = 10;
  if (!Number.isFinite(p.ui.dailyReviewLimit) || p.ui.dailyReviewLimit < 1) p.ui.dailyReviewLimit = 50;
  if (!Number.isFinite(p.ui.dailyNewLimit) || p.ui.dailyNewLimit < 0) p.ui.dailyNewLimit = 10;
  if (typeof p.ui.newOnlyAfterDue !== 'boolean') p.ui.newOnlyAfterDue = true;
  if (typeof p.ui.unlimitedStudy !== 'boolean') p.ui.unlimitedStudy = false;
  // V135: giới hạn 0–5 câu mỗi buổi; giá trị lạ/thiếu → 2 (giá trị mặc định).
  if (!Number.isFinite(p.ui.orderSentencePerSession)) p.ui.orderSentencePerSession = 2;
  p.ui.orderSentencePerSession = Math.max(0, Math.min(5, Math.round(p.ui.orderSentencePerSession)));
  p.ui.questionMix = normalizeQuestionMix(p.ui.questionMix);
  if (!Number.isFinite(p.ui.currentLesson)) p.ui.currentLesson = null;
  return p;
}
let progressState = defaultProgress();
// Áp dụng lại trạng thái đang thao tác dở (tab, Quyển/level, bài đang chọn, các cài đặt hiển thị)
// từ progressState.ui — gọi mỗi khi mở lại app hoặc đăng nhập xong, để khỏi phải chọn lại từ đầu.
function applyUIState() {
  normalizeProgress(progressState);
  const ui = progressState.ui;
  const validTabs = ['home','today','flash','quiz','type','listen','stats','skills','difficult','compare','convo','listening','aibank','ttsfix','admin','vocab'];
  currentTab = validTabs.includes(ui.lastTab) ? ui.lastTab : 'home';
  // Mục "HSK 4+" (id 8) đã bỏ khi khai báo lại HSK 1-5 = bài 33-37 — loại khỏi lựa chọn đã lưu để khỏi lỗi.
  selectedBookIds = new Set(ui.selectedBookIds.filter(id => id !== 8));
  selectedLessons = new Set(ui.selectedLessons);
  lessonsAllMode = ui.lessonsAllMode;
  showPinyin = ui.showPinyin;
  showMeaning = ui.showMeaning;
  showHanViet = ui.showHanViet;
  qzType = ui.qzType;
  qzQuestionCount = ui.qzQuestionCount;
  questionCount = ui.questionCount;
  ttsRate = ui.ttsRate;
  edgeTtsVoice = ui.ttsVoice || 'zh-CN-XiaoxiaoNeural';
  const voiceSelect = document.getElementById('tts-voice');
  if (voiceSelect) voiceSelect.value = edgeTtsVoice;
  const pyBtn = document.getElementById('py-toggle-btn');
  if (pyBtn) pyBtn.textContent = showPinyin ? 'Ẩn Pinyin' : 'Hiện Pinyin';
  const viBtn = document.getElementById('vi-toggle-btn');
  if (viBtn) viBtn.textContent = showMeaning ? 'Ẩn nghĩa' : 'Hiện nghĩa';
  const hvBtn = document.getElementById('hv-toggle-btn');
  if (hvBtn) hvBtn.textContent = showHanViet ? 'Ẩn Hán Việt' : 'Hiện Hán Việt';
  const speedSlider = document.getElementById('speed-slider');
  if (speedSlider) speedSlider.value = ttsRate;
  const speedVal = document.getElementById('speed-val');
  if (speedVal) speedVal.textContent = ttsRate.toFixed(2);
  applyTheme(ui.theme);
  if (typeof navHighlight === 'function') navHighlight(currentTab); // V116 (js/nav.js)
}
let authMode = 'login'; // 'login' | 'register'
let syncTimer = null;
let syncOk = true;
let currentRole = 'user';   // 'user' | 'admin' | 'superadmin'
let currentRank = null;     // {name, icon, next:{name,icon,remain}|null}
function isAdminRole() { return currentRole === 'admin' || currentRole === 'superadmin'; }

function authHeaders() {
  return authToken ? { 'Authorization': 'Bearer ' + authToken } : {};
}

function authSwitchTab(mode) {
  authMode = mode;
  document.getElementById('auth-tab-login').classList.toggle('active', mode === 'login');
  document.getElementById('auth-tab-register').classList.toggle('active', mode === 'register');
  document.getElementById('auth-submit').textContent = mode === 'login' ? 'Đăng nhập' : 'Đăng ký';
  document.getElementById('auth-error').classList.remove('show');
}

// V119.3 — Superadmin có thể TẮT trang đăng ký. Màn đăng nhập hỏi server (/api/auth/config) và, nếu đang tắt, ẩn tab "Đăng ký"
// kèm ghi chú. Lỗi mạng → giữ nguyên (không ẩn nhầm); server vẫn là nơi chặn thật sự.
let authRegistrationOpen = true;
function authApplyRegistration(open) {
  authRegistrationOpen = open !== false;
  const tab = document.getElementById('auth-tab-register');
  const note = document.getElementById('auth-note');
  if (tab) tab.style.display = authRegistrationOpen ? '' : 'none';
  if (note) {
    note.textContent = authRegistrationOpen ? '' : 'Trang đăng ký đang tạm đóng. Liên hệ quản trị viên để được cấp tài khoản.';
    note.classList.toggle('show', !authRegistrationOpen);
  }
  if (!authRegistrationOpen && authMode === 'register') authSwitchTab('login');
}
async function authLoadConfig() {
  try {
    const res = await fetch('/api/auth/config');
    const d = await res.json();
    if (d && d.ok) authApplyRegistration(d.registrationOpen);
  } catch { /* offline: giữ nguyên giao diện */ }
}

function authShowError(msg) {
  const el = document.getElementById('auth-error');
  el.textContent = msg;
  el.classList.add('show');
}

async function authSubmit() {
  const username = document.getElementById('auth-username').value.trim();
  const password = document.getElementById('auth-password').value;
  const btn = document.getElementById('auth-submit');
  if (!username || !password) { authShowError('Vui lòng nhập đầy đủ thông tin'); return; }
  btn.disabled = true;
  const oldLabel = btn.textContent; btn.textContent = 'Đang xử lý...';
  try {
    const res = await fetch('/api/' + authMode, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    const data = await res.json();
    if (!data.ok) {
      if (data.registrationClosed) authApplyRegistration(false); // đăng ký vừa bị tắt trong lúc đang mở màn hình
      authShowError(data.error || 'Có lỗi xảy ra'); return;
    }
    authToken = data.token; authUsername = data.username;
    localStorage.setItem('authToken', authToken);
    localStorage.setItem('authUsername', authUsername);
    studySession = { id: null, startedAt: 0, lastActivity: 0, cards: 0, correct: 0, wrong: 0 }; // Task 4/5: mỗi tài khoản có phiên học riêng, tránh lẫn phiên cũ
    // V77 (Study Day/Study Session): TRƯỚC ĐÂY đăng nhập luôn XOÁ TRẮNG sessionKnownHz — nghĩa là
    // đăng xuất rồi đăng nhập lại CÙNG NGÀY sẽ vô tình cho phép học lại đúng những từ vừa hoàn
    // thành trước đó (vi phạm Yêu cầu 3). Giờ nạp lại ĐÚNG bộ "đã hoàn thành hôm nay" đã lưu sẵn
    // (khoá theo đúng authUsername + đúng ngày, xem sessionKnownHzStoreKey ở study-queue.js) —
    // không còn xoá trắng, tài khoản này vẫn nhớ đúng những gì đã học trong ngày dù có đăng xuất/
    // đăng nhập lại giữa chừng.
    _sessionKnownHzDay = todayKey();
    sessionKnownHz = loadSessionKnownHz();
    progressState = data.progress || defaultProgress();
    currentRole = data.role || 'user';
    currentRank = data.rank || null;
    serverStreak = data.streak || 0;
    serverLongestStreak = data.longestStreak || 0;
    serverKnownCount = data.known || 0;
    applyUIState();
    cacheProgressLocally();
    closeAuthGate();
    render();
    // Không còn chế độ dùng thử: từ vựng chỉ tải được SAU khi đăng nhập (cần token) — tải ngay tại đây.
    if (typeof ensureVocabLoaded === 'function') {
      ensureVocabLoaded(selectedBookIds).then(() => {
        if (typeof mergeDiscoveredLessonsIntoBooks === 'function') mergeDiscoveredLessonsIntoBooks();
        render();
      });
    }
  } catch (e) {
    authShowError('Không kết nối được máy chủ. Kiểm tra mạng và thử lại.');
  } finally {
    btn.disabled = false; btn.textContent = oldLabel;
  }
}

function authOpenMenu() {
  if (!authUsername) { openAuthGate(); return; }
  document.getElementById('account-menu-name').textContent = '👤 ' + authUsername;
  document.getElementById('account-menu').style.display = 'flex';
}
function closeAccountMenu() { document.getElementById('account-menu').style.display = 'none'; }

function openChangePassword() {
  document.getElementById('pw-old').value = '';
  document.getElementById('pw-new').value = '';
  document.getElementById('pw-new2').value = '';
  document.getElementById('pw-error').classList.remove('show');
  document.getElementById('pw-modal').style.display = 'flex';
}
function closeChangePassword() { document.getElementById('pw-modal').style.display = 'none'; }

async function submitChangePassword() {
  const oldPassword = document.getElementById('pw-old').value;
  const newPassword = document.getElementById('pw-new').value;
  const newPassword2 = document.getElementById('pw-new2').value;
  const errEl = document.getElementById('pw-error');
  const showErr = (msg) => { errEl.textContent = msg; errEl.classList.add('show'); };
  if (!oldPassword || !newPassword) return showErr('Vui lòng nhập đủ thông tin.');
  if (newPassword.length < 4) return showErr('Mật khẩu mới cần tối thiểu 4 ký tự.');
  if (newPassword !== newPassword2) return showErr('Mật khẩu mới nhập lại không khớp.');
  const btn = document.getElementById('pw-submit');
  btn.disabled = true; btn.textContent = 'Đang xử lý...';
  try {
    const res = await fetch('/api/change-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({ oldPassword, newPassword }),
    });
    const data = await res.json();
    if (!data.ok) { showErr(data.error || 'Đổi mật khẩu thất bại.'); return; }
    closeChangePassword();
    alert('✅ Đổi mật khẩu thành công!');
  } catch (e) {
    showErr('Lỗi kết nối: ' + e.message);
  } finally {
    btn.disabled = false; btn.textContent = 'Đổi mật khẩu';
  }
}

async function authLogout() {
  try { await fetch('/api/logout', { method: 'POST', headers: authHeaders() }); } catch {}
  authToken = null; authUsername = null;
  currentRole = 'user'; currentRank = null;
  serverStreak = 0; serverLongestStreak = 0; serverKnownCount = 0;
  pauseStudyTimer(); studySession = { id: null, startedAt: 0, lastActivity: 0, cards: 0, correct: 0, wrong: 0 };
  // V77: KHÔNG còn xoá localStorage "đã hoàn thành hôm nay" của username vừa đăng xuất — dữ liệu
  // này thuộc về đúng Study Day hôm nay của tài khoản đó, phải còn nguyên nếu họ đăng nhập lại
  // trong CÙNG NGÀY (Yêu cầu 3). authUsername đổi về null ngay dưới đây nên set trong bộ nhớ cũng
  // phải đổi theo (không còn ai đăng nhập -> không có "đã hoàn thành hôm nay" nào áp dụng).
  sessionKnownHz = new Set();
  if (typeof wnReset === 'function') wnReset(); // V105: không giữ mẹo nhớ của người vừa đăng xuất
  if (typeof skResetState === 'function') skResetState(); // V104: không giữ số liệu kỹ năng của người vừa đăng xuất
  localStorage.removeItem('authToken'); localStorage.removeItem('authUsername');
  progressState = defaultProgress();
  applyUIState();
  openAuthGate();
}

function openAuthGate() {
  document.getElementById('auth-gate').style.display = 'flex';
  authLoadConfig(); // V119.3: ẩn/hiện tab Đăng ký theo cài đặt của superadmin
  document.getElementById('auth-username').value = '';
  document.getElementById('auth-password').value = '';
  document.getElementById('auth-error').classList.remove('show');
  document.getElementById('tab-admin').style.display = 'none';
  document.getElementById('tab-vocab').style.display = 'none';
  const ab = document.getElementById('tab-aibank'); if (ab) ab.style.display = 'none';
  const tf = document.getElementById('tab-ttsfix'); if (tf) tf.style.display = 'none'; // V129
}
function closeAuthGate() {
  document.getElementById('auth-gate').style.display = 'none';
  updateUserBadge();
  const showAdmin = isAdminRole() ? '' : 'none';
  document.getElementById('tab-admin').style.display = showAdmin;
  document.getElementById('tab-vocab').style.display = showAdmin;
  const tf = document.getElementById('tab-ttsfix'); if (tf) tf.style.display = showAdmin; // V129: Sửa phát âm chỉ cho quản trị viên
  if (typeof ttsHintsLoad === 'function') ttsHintsLoad(); // V129: tải "chữ đọc" đã sửa để 🔊 đọc đúng
  const ab = document.getElementById('tab-aibank'); if (ab) ab.style.display = showAdmin; // V119.2: Thư viện AI chỉ cho quản trị viên
}
function updateUserBadge() {
  const badge = document.getElementById('user-badge');
  if (!badge) return;
  const rankIcon = currentRank ? currentRank.icon + ' ' : '';
  badge.innerHTML = rankIcon + '👤 ' + authUsername + (currentRole === 'superadmin' ? ' 👑🛠️' : currentRole === 'admin' ? ' 🛠️' : '');
}

function cacheProgressLocally() {
  if (authUsername) {
    localStorage.setItem('progressCache_' + authUsername, JSON.stringify(progressState));
    localStorage.setItem('roleCache_' + authUsername, currentRole || 'user');
  }
}

// Đồng bộ lên server (gộp các lần lưu liên tiếp trong 700ms để đỡ tốn request)
function scheduleSync() {
  if (!authToken) return;
  syncOk = null; updateSyncIndicator();
  clearTimeout(syncTimer);
  syncTimer = setTimeout(async () => {
    try {
      const res = await fetch('/api/progress', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        body: JSON.stringify(progressState),
      });
      const data = await res.json();
      syncOk = !!data.ok;
      if (data.rank) { currentRank = data.rank; updateUserBadge(); }
    } catch { syncOk = false; }
    updateSyncIndicator();
  }, 700);
}
function updateSyncIndicator() {
  const badge = document.getElementById('user-badge');
  if (!badge || !authUsername) return;
  const dot = syncOk === false ? '<span class="sync-dot offline"></span>' : (syncOk === null ? '' : '<span class="sync-dot"></span>');
  const rankIcon = currentRank ? currentRank.icon + ' ' : '';
  badge.innerHTML = dot + rankIcon + '👤 ' + authUsername + (currentRole === 'superadmin' ? ' 👑🛠️' : currentRole === 'admin' ? ' 🛠️' : '');
}

// FIX (Vấn đề 5 — "Chọn bài học không hoạt động"): scheduleSync() debounce 700ms rồi mới đẩy
// progress.ui (gồm selectedBookIds/selectedLessons/lessonsAllMode) lên server. Nếu user vừa đổi
// Quyển/bài rồi bấm "Bắt đầu học"/vào tab luyện tập NGAY (trong vòng 700ms), server truy vấn
// /api/study/session vẫn đọc user.progress.ui CŨ (bản debounce chưa kịp chạy) — lấy nhầm đúng bộ
// lọc CŨ, trông như "chọn bài học không hoạt động". flushProgressSync() huỷ debounce hiện tại và
// đẩy NGAY, trả về promise để nơi gọi await được — đảm bảo server luôn thấy đúng lựa chọn MỚI NHẤT
// trước khi truy vấn bất kỳ dữ liệu học nào phụ thuộc vào nó (gọi ở loadFsrsPracticePool() và
// rvFetchFreshSession() ngay trước khi fetch /api/study/session).
async function flushProgressSync() {
  if (!authToken) return;
  clearTimeout(syncTimer);
  syncOk = null; updateSyncIndicator();
  try {
    const res = await fetch('/api/progress', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify(progressState),
    });
    const data = await res.json();
    syncOk = !!data.ok;
    if (data.rank) { currentRank = data.rank; updateUserBadge(); }
  } catch { syncOk = false; }
  updateSyncIndicator();
}

// Khởi động: nếu đã đăng nhập trước đó trên máy này, vào thẳng app bằng dữ liệu lưu tạm
// (không phải đợi mạng phản hồi mới cho vào — đây là nguyên nhân gây ra màn hình đăng nhập
// hiện thoáng qua vài giây mỗi lần mở app), rồi âm thầm đồng bộ lại với server phía sau.
async function bootAuth() {
  if (authToken && authUsername) {
    flushReviewOutbox(); // FIX (Task 3): tự gửi lại review còn kẹt trong outbox từ phiên trước (F5/mất mạng/đóng tab)
    const cachedRaw = localStorage.getItem('progressCache_' + authUsername);
    let enteredWithCache = false;
    if (cachedRaw) {
      try {
        progressState = JSON.parse(cachedRaw);
        currentRole = localStorage.getItem('roleCache_' + authUsername) || 'user';
        applyUIState();
        closeAuthGate();
        render();
        enteredWithCache = true;
      } catch {}
    }
    try {
      const res = await fetch('/api/progress', { headers: authHeaders() });
      const data = await res.json();
      if (data.ok) {
        progressState = data.progress || defaultProgress();
        currentRole = data.role || 'user';
        currentRank = data.rank || null;
        // V70 (Task 2 audit): streak/known THẬT từ server (study_sessions/fsrs_cards) — trước đây
        // client bỏ qua 2 trường này và tự tính streak cục bộ bằng SRS cũ đã bị xoá.
        serverStreak = data.streak || 0;
        serverLongestStreak = data.longestStreak || 0;
        serverKnownCount = data.known || 0;
        // Chỉ áp trạng thái tab/lựa chọn nếu đây là lần đầu vào (chưa có cache) — tránh việc
        // đang xem dở 1 tab rồi tự nhảy sang tab khác khi dữ liệu server về chậm hơn 1 chút.
        if (!enteredWithCache) applyUIState();
        cacheProgressLocally();
        closeAuthGate();
        if (enteredWithCache) { syncOk = true; updateSyncIndicator(); render(); }
        else render();
        return;
      }
      // Token không còn hợp lệ (vd tài khoản đã bị xoá, hoặc phiên đăng nhập hết hạn)
      if (!enteredWithCache) openAuthGate();
      else { syncOk = false; updateSyncIndicator(); }
    } catch {
      // Không có mạng / server chưa phản hồi kịp — nếu đã vào bằng cache thì cứ để vậy, đồng bộ lại sau
      if (!enteredWithCache) openAuthGate();
      else { syncOk = false; updateSyncIndicator(); }
    }
    return;
  }
  openAuthGate();
}

// ════════════════════════════════════════════════════
// V70 (Task 2 audit — hợp nhất FSRS): TOÀN BỘ hệ "SRS cục bộ" tự viết cũ (step cứng 10p/1h/1
// ngày/3 ngày/7 ngày, lưu trong progressState.srs) đã bị XOÁ khỏi client cho user ĐÃ ĐĂNG NHẬP.
// Lý do: nó là "review queue riêng" / "SRS cũ" chạy song song với FSRS-6 thật (Task 2 cấm), và
// thực ra backend đã ngừng lưu progress.srs từ trước (xem api/index.js `/api/progress` POST —
// "V69: chỉ còn ui, KHÔNG còn srs/streak") — client chỉ chưa được cập nhật theo kịp, khiến dữ
// liệu cũ này chỉ tồn tại "ảo" trên 1 thiết bị, không đồng bộ, không phải nguồn sự thật thật sự.
//
// Từ giờ:
//   - User ĐÃ ĐĂNG NHẬP: streak/known/độ ưu tiên từ đến hạn... đều lấy từ SERVER (FSRS-6 thật,
//     reviewService + fsrs_cards + review_history + study_sessions) — xem serverStreak/
//     serverKnownCount bên dưới + loadFsrsPracticePool()/submitFsrsReview() dùng ở các tab luyện tập.
//   - Không còn chế độ dùng thử/khách: chưa đăng nhập thì chỉ thấy màn hình đăng nhập.
// ════════════════════════════════════════════════════
let serverStreak = 0, serverLongestStreak = 0, serverKnownCount = 0;

// Streak hiển thị: số streak SERVER tính (từ study_sessions thật, Phần 11 Task 6).
function getStreak() { return serverStreak; }

// Gọi lại /api/progress để làm mới streak/known thật sau khi vừa hoàn thành 1 lượt/1 phiên luyện
// tập ở BẤT KỲ tab nào (Task 2: mọi tab đều là "nguồn sự thật" như nhau) — không gọi sau MỖI câu
// trả lời (tốn request), chỉ gọi khi kết thúc 1 phiên/1 thẻ để badge không bị cũ quá lâu.
let _refreshMetaTimer = null;
function refreshServerMeta() {
  if (!authToken) return;
  // AUDIT V82: xoá cache /api/study/today (lesson.js:fetchTodayDashboard) NGAY khi có phiên vừa
  // hoàn thành — nếu không, khối "at a glance" ở Trang chủ/tab "Hôm nay học" có thể hiện due/mới
  // CŨ tới 10s sau khi vừa học xong (TODAY_DASH_CACHE_TTL_MS), gây cảm giác số liệu "đứng hình".
  if (typeof _todayDashCache !== 'undefined') { _todayDashCache = null; _todayDashCacheAt = 0; }
  clearTimeout(_refreshMetaTimer);
  _refreshMetaTimer = setTimeout(async () => {
    try {
      const res = await fetch('/api/progress', { headers: authHeaders() });
      const data = await res.json();
      if (data.ok) {
        serverStreak = data.streak || 0;
        serverLongestStreak = data.longestStreak || 0;
        serverKnownCount = data.known || 0;
        currentRank = data.rank || currentRank;
        const badge = document.getElementById('streak-badge');
        if (badge) badge.textContent = '🔥 ' + getStreak() + ' ngày';
        updateUserBadge();
      }
    } catch { /* im lặng — không chặn luồng học vì lỗi làm mới badge */ }
  }, 900);
}

